package app;

public class InterfaceAmazonReview {

}
